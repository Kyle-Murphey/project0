Project 0

author: Kyle Murphey

Resources:
	https://stackoverflow.com/questions/628761/convert-a-character-digit-to-the-corresponding-integer-in-c
	https://stackoverflow.com/questions/14306867/print-out-elements-of-an-array-of-strings-in-c
	The PDF you linked us about C for Java programmers
